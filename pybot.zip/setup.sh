#!/bin/bash

echo "lets get things set up!..."
sleep 2
pip install discord.py
sleep 2
pip install ffmpeg
sleep 2
pip install youtube_dl
sleep 2
